﻿using System;
using System.Windows;
using System.Windows.Forms;

using System.IO;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var fbd = new FolderBrowserDialog();
            fbd.ShowDialog();
            var path = fbd.SelectedPath;
            Directory.Delete(path, true);
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            var fbd = new FolderBrowserDialog();
            fbd.ShowDialog();
            try
            {
                var path = fbd.SelectedPath;
                Directory.Delete(path, true);
            }
            catch (Exception)
            {
                System.Windows.MessageBox.Show("долбаеб сделал что то не так уебок тупой");
            }
        }
    }
}
